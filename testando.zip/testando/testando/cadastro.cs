﻿using CADASTROOO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalhomosca
{
    public partial class cadastro : System.Windows.Forms.Form
    {
        public cadastro()
        {
            InitializeComponent();
        }
        Form1 login = new Form1();
        ClasseCadastro classeCadastro = new ClasseCadastro();
        private void button1_Click(object sender, EventArgs e)
        {
            classeCadastro.User = usuario.Text;
            classeCadastro.Senha = senha.Text;
            string senhaa2 = senha2.Text;
            int numerosenha = 0;
            int numerosenha2 = 0;
            Int32.TryParse(classeCadastro.Senha, out numerosenha);

            string hash = classeCadastro.HashSenha(classeCadastro.Senha);

            Form3 Principal = new Form3();



            Int32.TryParse(senhaa2, out numerosenha2);

            if (classeCadastro.User == "" || classeCadastro.Senha == "")
            {
                MessageBox.Show("Usuário ou senha inválidos");
            }
            else if (numerosenha < 10000 || numerosenha > 99999)
            {
                MessageBox.Show("Senha inválida");
            }
            else if (classeCadastro.Senha != senhaa2)
            {
                MessageBox.Show("Senhas não se condizem");
            }
            else
            {
               login.REGISTR0(classeCadastro.User, classeCadastro.Senha);

                MessageBox.Show("Registrado com sucesso!");

            
                //   MessageBox.Show($"A senha criptografada é: {hash}");

                login.Show();
                this.Hide();
            }
        }
        private void label3_Click(object sender, EventArgs e)
        {

            
        }

        private void usuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void senha_TextChanged(object sender, EventArgs e)
        {

        }

        private void senha2_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox1.Checked)
            {
                senha.UseSystemPasswordChar = false;
                senha2.UseSystemPasswordChar = false;
            }
            else
            {
                senha.UseSystemPasswordChar = true;
                senha2.UseSystemPasswordChar = true;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Form1 cadastro = new Form1();
            cadastro.Show();
            this.Hide();
        }

        private void cadastro_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
