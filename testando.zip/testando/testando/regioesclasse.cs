﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REGIOES
{
    internal class regioesclasse
    {
        public List<string> Sul;
        public List<string> Leste;
        public List<string> Oeste;
        public List<string> Norte;

        public void SulClass (string sul)    
        {        
            if (Sul == null) Sul = new List<string>();
            
            if (Sul != null) Sul.Add(sul);
        }

        public void LesteClass(string leste)
        {      
            if (Leste == null) Leste = new List<string>();

            if (Leste != null) Leste.Add(leste);
        }

        public void OesteClass(string oeste)
        {
            if (Oeste == null) Oeste = new List<string>();
            
            if (Oeste != null) Oeste.Add(oeste);
        }

        public void NorteClass(string norte)
        {
            if (Norte == null) Norte = new List<string>();
            
            if (Norte != null) Norte.Add(norte);    
        }

    }
}
