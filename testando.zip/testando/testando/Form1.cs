﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalhomosca
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string usuario;
        string senha;
        public void REGISTR0(string user, string password)

        {
            usuario = user;
            senha = password;

        }

        const string admin = "admin";
        const string senhadmin = "12345";
        private void button1_Click(object sender, EventArgs e)
        {
            if (usercad.Text == usuario && senhacad.Text == senha)

            {
                MessageBox.Show("Login feito com sucesso!");
                principal principal = new principal();
                principal.Show();
                this.Hide();

            }

            else if (usercad.Text == admin && senhacad.Text == senhadmin)
            {
                MessageBox.Show("Login feito com sucesso!");
                principal principal = new principal();
                principal.Show();
                this.Hide();
            }

            else
            {
                MessageBox.Show("Login incorreto!");
            }

        }

        private void usercad_TextChanged(object sender, EventArgs e)
        {

        }

        private void senhacad_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                senhacad.UseSystemPasswordChar = false;
            }
            else
            {
                senhacad.UseSystemPasswordChar = true;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            cadastro cadastro = new cadastro();
            cadastro.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
