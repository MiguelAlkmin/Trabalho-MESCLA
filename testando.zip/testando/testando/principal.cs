﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalhomosca
{
    public partial class principal : System.Windows.Forms.Form
    {

        public principal()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int urgente = 0;
            string regiao = regiaoo.Text;
            int reg = 0;
            Int32.TryParse(Urgencia.Text, out urgente);

            Form3 ob = new Form3();
            string reclamaco = textBox4.Text;

            ob.Receber(reclamaco);
            ob.Urgencia(urgente);

                switch (regiao)
                {
                    case "NORTE":
                        reg = 1;

                        break;

                    case "LESTE":
                        reg = 2;

                        break;

                    case "OESTE":
                        reg = 3;
                        break;

                    case "SUL":
                        reg = 4;
                        break;

                }
                ob.Regioes(reg);
            System.DateTime dt1 = dateTimePicker1.Value;
            System.DateTime dt2 = dateTimePicker2.Value;
            System.TimeSpan dias = dt2.Subtract(dt1);
            ob.DIAS(dias);
            MessageBox.Show("Reclamação adicionada com sucesso!");
             
                ob.Show();
            this.Hide();

            

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Urgencia_TextChanged(object sender, EventArgs e)
        {

        }

        private void regiaoo_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "MM/dd/yyyy hh:mm:ss";
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "MM/dd/yyyy hh:mm:ss";
        }

        private void label6_Click(object sender, EventArgs e)
        {
           Form2 cadastro = new Form2();
            cadastro.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
