﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using  REGIOES;

namespace trabalhomosca
{
    public partial class Form4 : System.Windows.Forms.Form
    {
        regioesclasse regioesclasse;
        public Form4()
        {
            InitializeComponent();
            if (regioesclasse == null)
            {
                regioesclasse = new regioesclasse();
            }

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        public void Norte(string norterecx)
        {

            regioesclasse.NorteClass(norterecx);
            foreach (string n in regioesclasse.Norte)
            {
                label6.Text = ($"\n{n}");
            }

        }
        public void Sul(string sulrecx)
        {

            regioesclasse.SulClass(sulrecx);
            foreach (string n in regioesclasse.Sul)
            {
                label7.Text = ($"\n{n}");
            }
        }
        public void Leste(string lesterecx)
        {

            regioesclasse.LesteClass(lesterecx);
            foreach (string n in regioesclasse.Leste)
            {
                label8.Text = ($"\n{n}");
            }
        }
        public void Oeste(string oesterecx)
        {

            regioesclasse.OesteClass(oesterecx);
            foreach (string n in regioesclasse.Oeste)
            {
                label9.Text = ($"\n{n}");
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
            principal PRINCIPAL = new principal();
            PRINCIPAL.Show();
            this.Hide();

        }

        private void label6_Click(object sender, EventArgs e)
        {

      }
    }
}
