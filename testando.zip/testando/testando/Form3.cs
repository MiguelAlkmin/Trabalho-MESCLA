﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalhomosca
{
    public partial class Form3 : System.Windows.Forms.Form
    {
        Form4 list;
        public Form3()
        {
            InitializeComponent();
            if (list == null)
            {
                list = new Form4();
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        string reclamaX;
        public void Receber(string reclamacao)
        {
            label2.Text = reclamacao;
            reclamaX = reclamacao;

        }

    
        public void Urgencia(int urgente)
        {
            switch (urgente)
            {
                case 1:

                    label6.Text = "Urgência nível VERDE - O problema pode ser resolvido em longo prazo";

                    break;

                case 2:

                    label6.Text = "Urgência nível AMARELO - O problema pode ser resolvido em médio prazo";

                    break;


                case 3:

                    label6.Text = "Urgência nível VERMELHO - O problema deve ser resolvido em curto prazo ";

                    break;

                default:

                    label6.Text = "Número inválido";

                    break;
            }
        }

        public void Regioes(int regiao)
        {
            switch (regiao)
            {
                case 1:

                    label5.Text = "Região NORTE";
                    list.Norte(reclamaX);
                    break;

                case 2:

                    label5.Text = "Região LESTE";
                    list.Leste(reclamaX);
                    break;

                case 3:

                    label5.Text = "Região OESTE";
                    list.Oeste(reclamaX);
                    break;

                case 4:

                    label5.Text = "Região SUL";
                    list.Sul(reclamaX);
                    break;

                default:

                    label5.Text = "Região inválida";
                    break;

            }
        }
        public void DIAS (TimeSpan dias)
        {
            string diasdois = string.Format("{0}", dias.Days.ToString("d"));
            string diastres = diasdois;

            /* TimeSpan t = dateTimePicker2.Value.ToLocalTime() - dateTimePicker1.Value.ToLocalTime();
             string x = TimeSpan.Parse(t.Days.ToString());*/
            databox.Text = "Quantidade de dias: " + diastres;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            list.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void databox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label_Click(object sender, EventArgs e)
        {

        }
    }
}